__turbopack_load_page_chunks__("/CompleteReset", [
  "static/chunks/node_modules_next_aae990._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__41f3b0._.js",
  "static/chunks/src_pages_CompleteReset_index_5771e1.js",
  "static/chunks/src_pages_CompleteReset_index_2d4bf6.js"
])
