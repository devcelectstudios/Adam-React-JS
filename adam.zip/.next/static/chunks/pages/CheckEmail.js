__turbopack_load_page_chunks__("/CheckEmail", [
  "static/chunks/node_modules_next_aae990._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__aded87._.js",
  "static/chunks/src_pages_CheckEmail_index_5771e1.js",
  "static/chunks/src_pages_CheckEmail_index_48b866.js"
])
