__turbopack_load_page_chunks__("/CreateNewPass", [
  "static/chunks/node_modules_next_aae990._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_bad01e._.js",
  "static/chunks/node_modules_react-icons_lib_75a63d._.js",
  "static/chunks/node_modules_1b7400._.js",
  "static/chunks/[root of the server]__d4d544._.js",
  "static/chunks/src_pages_CreateNewPass_index_5771e1.js",
  "static/chunks/src_pages_CreateNewPass_index_8265da.js"
])
