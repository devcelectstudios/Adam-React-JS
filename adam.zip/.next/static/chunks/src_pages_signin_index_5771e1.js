(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_signin_index_5771e1.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_signin_index_5771e1.js",
  "chunks": [
    "static/chunks/node_modules_next_aae990._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_1b7400._.js",
    "static/chunks/[root of the server]__7f6c18._.js"
  ],
  "source": "entry"
});
